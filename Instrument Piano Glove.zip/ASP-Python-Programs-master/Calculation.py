def calculation(a, b):
    print( a + b )
    print( a - b )
    print( a * b )
    if a != 0 and b != 0:
        print(a / b)
    else:
        print('division with 0 is not possible')
        
