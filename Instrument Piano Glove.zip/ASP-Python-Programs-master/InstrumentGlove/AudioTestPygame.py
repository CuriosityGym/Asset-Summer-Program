import pygame
pygame.mixer.init()
pygame.mixer.music.load("Applause.wav")
pygame.mixer.music.play()
