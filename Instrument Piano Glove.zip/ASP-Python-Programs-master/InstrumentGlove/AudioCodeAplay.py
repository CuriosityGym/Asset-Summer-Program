import os
os.system('aplay Applause.wav')
